# SeamCarver

To build this seam carver simply run "make"

To run it execute 

	./seamCarver image.pgm cols rows

where cols is the number of columns to remove and rows is the number of rows to remove.
